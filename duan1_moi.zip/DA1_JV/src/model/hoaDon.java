/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;


public class hoaDon {
    public int id_hoaDon;
    public int id_hoaDonCt;
    public int nhanVien;
    public String tenNhanVien;
    public int trangThai;
    public String ngayTao;
    public int khachHang;
    public String tenKhachHang;
    public String id_sanPham;
    public String tenSanPham;
    public int soLuong;
    public double donGia;
    public int theLoai;
    public String tenTheLoai;
    public int chatLieu;
    public String tenChatLieu;
    public int thuongHieu;
    public String tenThuongHieu;
    public int nhaCungCap;
    public String tenNhaCungCap;
    public int mau;
    public String tenMau;
    public int size;
}
