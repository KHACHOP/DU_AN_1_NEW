/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import model.nhanVien;

/**
 *
 * @author MSI
 */
public interface nhanVien_service {
    public void themNhanVien(nhanVien nv);
    public void suaNhanVien(nhanVien nv);
            
            
}
