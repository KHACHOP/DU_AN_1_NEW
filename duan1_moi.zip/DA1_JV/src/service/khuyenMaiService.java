/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import model.khuyenMai;

/**
 *
 * @author MSI
 */
public interface khuyenMaiService {
    public void themKhuyenMai(khuyenMai kh);
    public void suaKhuyenMai(khuyenMai kh);
    public void xoaKhuyenMai(khuyenMai kh);
    
}
